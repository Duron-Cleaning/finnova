// Elementos del DOM
const editModal = document.getElementById('editModal');
const passwordModal = document.getElementById('passwordModal');
const modalTitle = document.getElementById('modalTitle');
const modalLabel = document.getElementById('modalLabel');
const modalInput = document.getElementById('modalInput');

// Campo actual siendo editado
let campoActual = '';

// Datos de ejemplo del usuario (en producción vendrían de una API)
let userData = {
    nombre: 'Juan Pérez',
    email: 'juan.perez@email.com',
    telefono: '+504 9999-9999'
};

// Validaciones
const validaciones = {
    email: (value) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(value) ? '' : 'Ingresa un correo electrónico válido';
    },
    telefono: (value) => {
        const telefonoRegex = /^\+504 \d{4}-\d{4}$/;
        return telefonoRegex.test(value) ? '' : 'Ingresa un número de teléfono válido (+504 XXXX-XXXX)';
    },
    nombre: (value) => {
        return value.length >= 3 ? '' : 'El nombre debe tener al menos 3 caracteres';
    }
};

// Abrir modal de edición
function editarCampo(campo) {
    campoActual = campo;
    const valor = userData[campo];
    
    modalTitle.textContent = `Editar ${getCampoLabel(campo)}`;
    modalLabel.textContent = getCampoLabel(campo);
    modalInput.value = valor;
    modalInput.type = campo === 'email' ? 'email' : 'text';
    
    if (campo === 'telefono') {
        modalInput.placeholder = '+504 XXXX-XXXX';
    }
    
    editModal.style.display = 'block';
}

// Obtener label del campo
function getCampoLabel(campo) {
    const labels = {
        nombre: 'Nombre completo',
        email: 'Correo electrónico',
        telefono: 'Teléfono'
    };
    return labels[campo];
}

// Guardar cambios
async function guardarCambios(event) {
    event.preventDefault();
    const valor = modalInput.value.trim();
    const errorMessage = validaciones[campoActual](valor);
    const errorElement = modalInput.nextElementSibling;

    if (errorMessage) {
        errorElement.textContent = errorMessage;
        return;
    }

    try {
        // Aquí iría la llamada a la API para actualizar los datos
        await simularLlamadaAPI();
        
        // Actualizar datos locales
        userData[campoActual] = valor;
        document.getElementById(`${campoActual}Usuario`).textContent = valor;
        
        // Cerrar modal
        cerrarModal();
        
        // Mostrar mensaje de éxito
        alert('Datos actualizados correctamente');
    } catch (error) {
        alert('Error al actualizar los datos. Por favor, intenta nuevamente.');
    }
}

// Cambiar contraseña
function cambiarPassword() {
    passwordModal.style.display = 'block';
}

// Guardar nueva contraseña
async function guardarPassword(event) {
    event.preventDefault();
    const currentPassword = document.getElementById('currentPassword');
    const newPassword = document.getElementById('newPassword');
    const confirmPassword = document.getElementById('confirmPassword');

    // Validar que las contraseñas coincidan
    if (newPassword.value !== confirmPassword.value) {
        confirmPassword.nextElementSibling.textContent = 'Las contraseñas no coinciden';
        return;
    }

    // Validar longitud mínima
    if (newPassword.value.length < 8) {
        newPassword.nextElementSibling.textContent = 'La contraseña debe tener al menos 8 caracteres';
        return;
    }

    try {
        // Aquí iría la llamada a la API para cambiar la contraseña
        await simularLlamadaAPI();
        
        // Limpiar formulario y cerrar modal
        document.getElementById('passwordForm').reset();
        cerrarModalPassword();
        
        // Mostrar mensaje de éxito
        alert('Contraseña actualizada correctamente');
    } catch (error) {
        alert('Error al actualizar la contraseña. Por favor, intenta nuevamente.');
    }
}

// Cerrar sesión
async function cerrarSesion() {
    if (confirm('¿Estás seguro que deseas cerrar sesión?')) {
        try {
            // Aquí iría la llamada a la API para cerrar sesión
            await simularLlamadaAPI();
            
            // Redireccionar al login
            window.location.href = 'login.html';
        } catch (error) {
            alert('Error al cerrar sesión. Por favor, intenta nuevamente.');
        }
    }
}

// Funciones auxiliares
function cerrarModal() {
    editModal.style.display = 'none';
    modalInput.nextElementSibling.textContent = '';
}

function cerrarModalPassword() {
    passwordModal.style.display = 'none';
    document.getElementById('passwordForm').reset();
    document.querySelectorAll('#passwordForm .error-message').forEach(error => {
        error.textContent = '';
    });
}

// Simular llamada a API
function simularLlamadaAPI() {
    return new Promise((resolve) => setTimeout(resolve, 1000));
}

// Event listeners
window.onclick = function(event) {
    if (event.target == editModal) {
        cerrarModal();
    }
    if (event.target == passwordModal) {
        cerrarModalPassword();
    }
};
