document.addEventListener('DOMContentLoaded', function() {
    // Variables iniciales
    let plazoSeleccionado = 3;
    const tasaInteresMensual = 0.05; // 5% mensual
    const comisionPorcentaje = 0.03; // 3% de comisión

    // Elementos del DOM
    const montoSlider = document.getElementById('montoSlider');
    const montoValue = document.querySelector('.monto-value');
    const totalDesembolsado = document.getElementById('totalDesembolsado');
    const cuotaMensual = document.getElementById('cuotaMensual');
    const amortizacion = document.getElementById('amortizacion');
    const fechaPago = document.getElementById('fechaPago');
    const plazoBotones = document.querySelectorAll('.plazo-button');
    const siguienteButton = document.querySelector('.siguiente-button');

    // Función para formatear montos en Lempiras
    function formatoLempiras(monto) {
        return `L. ${monto.toLocaleString('es-HN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }

    // Función para calcular la fecha del primer pago (30 días después)
    function calcularFechaPrimerPago() {
        const fecha = new Date();
        fecha.setDate(fecha.getDate() + 30);
        return fecha.toLocaleDateString('es-HN');
    }

    // Función para calcular la cuota mensual
    function calcularCuotaMensual(monto, plazo) {
        const montoConInteres = monto * (1 + (tasaInteresMensual * plazo));
        return montoConInteres / plazo;
    }

    // Función para calcular la amortización proporcional
    function calcularAmortizacion(monto) {
        // Calculamos la proporción entre el monto actual y el rango total
        const proporcion = (monto - 700) / (7000 - 700);
        // Calculamos la amortización proporcional entre 210 y 2100
        const amortizacion = 210 + (proporcion * (2100 - 210));
        return amortizacion;
    }

    // Función para actualizar todos los valores
    function actualizarValores() {
        const montoSeleccionado = parseInt(montoSlider.value);
        const comision = montoSeleccionado * comisionPorcentaje;
        const montoDesembolsado = montoSeleccionado - comision;
        const cuota = calcularCuotaMensual(montoSeleccionado, plazoSeleccionado);
        const amortizacionCalculada = calcularAmortizacion(montoSeleccionado);

        montoValue.textContent = formatoLempiras(montoSeleccionado);
        totalDesembolsado.textContent = formatoLempiras(montoDesembolsado);
        cuotaMensual.textContent = formatoLempiras(cuota);
        amortizacion.textContent = formatoLempiras(amortizacionCalculada);
        fechaPago.textContent = calcularFechaPrimerPago();

        // Guardar valores para el formulario de solicitud
        localStorage.setItem('montoSimulado', montoSeleccionado);
        localStorage.setItem('plazoSimulado', plazoSeleccionado);
        localStorage.setItem('cuotaSimulada', cuota);
        localStorage.setItem('desembolsoSimulado', montoDesembolsado);
        localStorage.setItem('fechaPagoSimulada', calcularFechaPrimerPago());
    }

    // Event Listeners
    montoSlider.addEventListener('input', function() {
        actualizarValores();
    });

    plazoBotones.forEach(boton => {
        boton.addEventListener('click', function() {
            // Remover clase active de todos los botones
            plazoBotones.forEach(b => b.classList.remove('active'));
            // Agregar clase active al botón seleccionado
            this.classList.add('active');
            // Actualizar plazo seleccionado
            plazoSeleccionado = parseInt(this.dataset.meses);
            actualizarValores();
        });
    });

    // Event listener para el botón Siguiente
    if (siguienteButton) {
        siguienteButton.addEventListener('click', function() {
            window.location.href = 'completar-solicitud.html';
        });
    }

    // Inicializar valores
    plazoBotones[0].classList.add('active');
    actualizarValores();
});
