document.addEventListener('DOMContentLoaded', function() {
    // Manejo de la foto de perfil
    const profilePhotoInput = document.getElementById('profile-photo');
    const profileImageContainer = document.getElementById('profile-image-container');
    let currentProfileImage = localStorage.getItem('profileImage');

    // Cargar imagen guardada si existe
    if (currentProfileImage) {
        profileImageContainer.innerHTML = `<img src="${currentProfileImage}" alt="Foto de perfil">`;
    }

    profilePhotoInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) { // 5MB máximo
                mostrarNotificacion('La imagen no debe superar los 5MB', 'error');
                return;
            }

            const reader = new FileReader();
            reader.onload = function(event) {
                const imageUrl = event.target.result;
                profileImageContainer.innerHTML = `<img src="${imageUrl}" alt="Foto de perfil">`;
                localStorage.setItem('profileImage', imageUrl);
                mostrarNotificacion('Foto de perfil actualizada');
            };
            reader.readAsDataURL(file);
        }
    });

    // Funcionalidad para los botones de editar
    const camposEditables = document.querySelectorAll('.campo');
    
    camposEditables.forEach(campo => {
        const input = campo.querySelector('input');
        const btnEditar = campo.querySelector('.btn-editar');
        let valorOriginal = input.value;

        btnEditar.addEventListener('click', function() {
            if (input.disabled) {
                // Modo edición
                input.disabled = false;
                input.focus();
                btnEditar.innerHTML = `
                    <span class="material-icons">save</span>
                    Guardar
                `;
                btnEditar.style.backgroundColor = '#4a148c';
                btnEditar.style.color = 'white';
            } else {
                // Guardar cambios
                if (input.value.trim() === '') {
                    mostrarNotificacion('Este campo no puede estar vacío', 'error');
                    input.value = valorOriginal;
                    return;
                }

                // Aquí iría la lógica para guardar en el backend
                valorOriginal = input.value;
                input.disabled = true;
                btnEditar.innerHTML = `
                    <span class="material-icons">edit</span>
                    Editar
                `;
                btnEditar.style.backgroundColor = '#f0e6ff';
                btnEditar.style.color = '#4a148c';

                mostrarNotificacion('Cambios guardados correctamente');
            }
        });
    });

    // Cambiar contraseña
    const btnCambiarContrasena = document.querySelector('.seguridad .btn-accion');
    btnCambiarContrasena.addEventListener('click', function() {
        const contrasenaActual = prompt('Ingresa tu contraseña actual:');
        if (!contrasenaActual) return;

        const nuevaContrasena = prompt('Ingresa tu nueva contraseña:');
        if (!nuevaContrasena) return;

        const confirmarContrasena = prompt('Confirma tu nueva contraseña:');
        if (!confirmarContrasena) return;

        if (nuevaContrasena !== confirmarContrasena) {
            mostrarNotificacion('Las contraseñas no coinciden', 'error');
            return;
        }

        // Aquí iría la lógica para cambiar la contraseña en el backend
        mostrarNotificacion('Contraseña actualizada correctamente');
    });

    // Ver historial
    const btnHistorial = document.querySelector('.historial .btn-accion');
    btnHistorial.addEventListener('click', function() {
        window.location.href = 'historial-creditos.html';
    });

    // Cerrar sesión
    const btnCerrarSesion = document.querySelector('.btn-cerrar-sesion');
    btnCerrarSesion.addEventListener('click', function() {
        if (confirm('¿Estás seguro que deseas cerrar sesión?')) {
            localStorage.removeItem('profileImage'); // Mantener otros datos si es necesario
            window.location.href = 'index.html';
        }
    });

    // Función para mostrar notificaciones
    function mostrarNotificacion(mensaje, tipo = 'success') {
        const notificacion = document.createElement('div');
        notificacion.className = 'notificacion';
        notificacion.textContent = mensaje;
        
        const backgroundColor = tipo === 'error' ? '#d32f2f' : '#4a148c';
        
        Object.assign(notificacion.style, {
            position: 'fixed',
            top: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: backgroundColor,
            color: 'white',
            padding: '12px 24px',
            borderRadius: '8px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
            zIndex: '1000',
            animation: 'fadeInOut 3s forwards'
        });

        // Agregar animación al CSS si no existe
        if (!document.querySelector('#notificacion-style')) {
            const style = document.createElement('style');
            style.id = 'notificacion-style';
            style.textContent = `
                @keyframes fadeInOut {
                    0% { opacity: 0; transform: translate(-50%, -20px); }
                    10% { opacity: 1; transform: translate(-50%, 0); }
                    90% { opacity: 1; transform: translate(-50%, 0); }
                    100% { opacity: 0; transform: translate(-50%, -20px); }
                }
            `;
            document.head.appendChild(style);
        }

        document.body.appendChild(notificacion);

        setTimeout(() => {
            document.body.removeChild(notificacion);
        }, 3000);
    }
});
